# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.game', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.game.brain_calc:calc',
                     'brain-even = brain_games.game.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '<a href="https://codeclimate.com/github/attackofanil/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b38df574ff61bb6ce653/maintainability" /></a>\n\nhttps://asciinema.org/a/f6f4bt5esiAD5cTzCowV8gzrT\n',
    'author': 'Саша Березин',
    'author_email': 'attackofsnail@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
