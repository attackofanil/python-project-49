<a href="https://codeclimate.com/github/attackofanil/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/b38df574ff61bb6ce653/maintainability" /></a>

https://asciinema.org/a/f6f4bt5esiAD5cTzCowV8gzrT
